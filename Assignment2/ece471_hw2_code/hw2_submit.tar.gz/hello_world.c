#include <stdio.h>

int main(int argc, char **argv) {

	int	i=0;
	for (i=1;i<14;i++)
	{
		printf("#%d: Don't fear, I AM HERE\n",i);
	}
	return 0;
}
