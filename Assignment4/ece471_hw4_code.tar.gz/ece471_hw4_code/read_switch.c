#include <stdio.h>

#include <fcntl.h>	/* open() */
#include <unistd.h>	/* close() */
#include <string.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <linux/gpio.h>
#include <sys/time.h>

static void switch_pressed(void) {

	struct timeval press_time;

	gettimeofday(&press_time,NULL);

	printf("Switch pressed at  %ld.%06ld\n",press_time.tv_sec,press_time.tv_usec);

}

static void switch_released(void) {

	struct timeval release_time;

	gettimeofday(&release_time,NULL);

	printf("Switch released at %ld.%06ld\n",release_time.tv_sec,release_time.tv_usec);

}


int main(int argc, char **argv) {

	switch_pressed();
	switch_released();

	return 0;
}
